"""
Datalag for prestasjonssenteret.

Leser CSV-filene fra hent_data.py og hent_ekstra.py, slår dem sammen og
regner ut indikatorer og innsikter. Alt baseres på faktiske målinger.
Der datagrunnlaget er for tynt, returneres ingenting i stedet for gjetning.

Kilder merkes konsekvent:
  "Garmin"    = verdien kommer direkte fra Garmin
  "Beregnet"  = utledet her fra dine Garmin-data
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path(__file__).parent / "data"

def _k(x, spec):
    """Tall med norsk desimalkomma."""
    return format(x, spec).replace(".", ",")


SPORTER = ["Svømming", "Sykling", "Løping", "Styrke", "Annet"]


# ------------------------------------------------------------------ innlesing

def _les(navn: str, datokol: str | None = None) -> pd.DataFrame:
    f = DATA / navn
    if not f.exists():
        return pd.DataFrame()
    df = pd.read_csv(f)
    if datokol and datokol in df:
        df[datokol] = pd.to_datetime(df[datokol], errors="coerce")
    return df


def sport_av(type_key) -> str:
    t = str(type_key or "").lower()
    if "swim" in t:
        return "Svømming"
    if any(k in t for k in ("cycl", "bik", "ride", "spin")):
        return "Sykling"
    if "run" in t:
        return "Løping"
    if any(k in t for k in ("strength", "fitness_equipment")):
        return "Styrke"
    return "Annet"


@dataclass
class Data:
    dag: pd.DataFrame                 # én rad per kalenderdag, indeks = dato
    okter: pd.DataFrame               # én rad per økt
    terskler: pd.DataFrame = field(default_factory=pd.DataFrame)
    prognoser: pd.DataFrame = field(default_factory=pd.DataFrame)
    last_kilde: str = "Garmin"        # "Garmin" eller "Beregnet"
    har_ekstra: bool = False

    def har(self, kol: str, df: pd.DataFrame | None = None) -> bool:
        df = self.dag if df is None else df
        return kol in df.columns and df[kol].notna().any()


def last_alt() -> Data | None:
    daglig = _les("daglig.csv", "dato")
    ekstra = _les("ekstra_daglig.csv", "dato")
    if daglig.empty and ekstra.empty:
        return None

    if daglig.empty:
        dag = ekstra
    elif ekstra.empty:
        dag = daglig
    else:
        dag = daglig.merge(ekstra, on="dato", how="outer")

    vekt = _les("vekt.csv", "dato")
    if not vekt.empty:
        dag = dag.merge(vekt, on="dato", how="outer")

    # ---- økter: detaljert fil hvis den finnes, ellers den opprinnelige
    det = _les("aktiviteter_detaljer.csv", "start")
    if not det.empty:
        ok = det.copy()
        ok["minutter"] = ok["varighet_s"] / 60
        ok["km"] = ok["distanse_m"] / 1000
    else:
        ok = _les("aktiviteter.csv", "start")
    if not ok.empty:
        ok = ok.dropna(subset=["start"]).copy()
        ok["sport"] = ok["type"].map(sport_av)
        ok["dato"] = ok["start"].dt.normalize()
        ok = ok.sort_values("start").reset_index(drop=True)

    # ---- kalender med alle dager
    start = min([d for d in [dag["dato"].min(), ok["dato"].min() if not ok.empty else None] if pd.notna(d)])
    slutt = max([d for d in [dag["dato"].max(), ok["dato"].max() if not ok.empty else None] if pd.notna(d)])
    dag = dag.drop_duplicates("dato").set_index("dato").sort_index()
    dag = dag.reindex(pd.date_range(start, slutt, freq="D"))
    dag.index.name = "dato"

    # ---- øktbelastning per økt: Garmins tall, ellers TRIMP beregnet fra puls
    if not ok.empty:
        ok["belastning"] = ok["treningslast"] if "treningslast" in ok else np.nan
        mangler = ok["belastning"].isna()
        if mangler.any() and "snittpuls" in ok:
            hr_maks = ok["makspuls"].quantile(0.98) if "makspuls" in ok and ok["makspuls"].notna().any() else None
            hr_hvile = dag["hvilepuls"].median() if "hvilepuls" in dag and dag["hvilepuls"].notna().any() else None
            if hr_maks and hr_hvile and hr_maks > hr_hvile:
                x = ((ok["snittpuls"] - hr_hvile) / (hr_maks - hr_hvile)).clip(0, 1)
                trimp = ok["minutter"] * x * 0.64 * np.exp(1.92 * x)
                ok.loc[mangler, "belastning"] = trimp[mangler]
                ok["belastning_beregnet"] = mangler
        per_dag = ok.groupby("dato").agg(
            okter=("start", "size"), trening_min=("minutter", "sum"), okt_belastning=("belastning", "sum"))
        dag = dag.join(per_dag)
        for k in ["okter", "trening_min"]:
            dag[k] = dag[k].fillna(0)
        dag["okt_belastning"] = dag["okt_belastning"].fillna(0) if ok["belastning"].notna().any() else np.nan

        # pulssoner → tre-sone intensitet (lav = 1–2, moderat = 3, høy = 4–5)
        soner = [f"puls_sone{i}_s" for i in range(1, 6)]
        if all(s in ok for s in soner) and ok[soner].notna().any().any():
            ok["int_lav_min"] = ok[soner[:2]].sum(axis=1, min_count=1) / 60
            ok["int_mod_min"] = ok[soner[2]] / 60
            ok["int_hoy_min"] = ok[soner[3:]].sum(axis=1, min_count=1) / 60
    else:
        dag["okter"] = 0
        dag["trening_min"] = 0

    # ---- akutt/kronisk belastning: Garmin hvis tilgjengelig, ellers beregnet
    last_kilde = "Garmin"
    if not ("belastning_akutt" in dag and dag["belastning_akutt"].notna().sum() >= 7):
        last_kilde = "Beregnet"
        if "okt_belastning" in dag and dag["okt_belastning"].notna().any():
            dag["belastning_akutt"] = dag["okt_belastning"].rolling(7, min_periods=7).sum()
            dag["belastning_kronisk"] = dag["okt_belastning"].rolling(28, min_periods=28).sum() / 4
            dag["acwr"] = dag["belastning_akutt"] / dag["belastning_kronisk"].replace(0, np.nan)

    # VO2 maks: Garmin oppgir «siste verdi»; behold bare dager der verdien faktisk ble målt/oppdatert
    for kol in ["vo2max_lop", "vo2max_sykkel"]:
        if f"{kol}_dato" in dag:
            dag[f"{kol}_ny"] = dag[kol].where(dag[f"{kol}_dato"].astype(str).str[:10] == dag.index.strftime("%Y-%m-%d"))

    terskler = _les("terskler.csv", "dato")
    prognoser = _les("prognoser.csv", "dato")
    return Data(dag=dag, okter=ok, terskler=terskler, prognoser=prognoser,
                last_kilde=last_kilde, har_ekstra=not ekstra.empty)


# ------------------------------------------------------------------ statistikk

def norm(serie: pd.Series, til: pd.Timestamp, dager: int = 30, min_n: int = 10):
    """Personlig normalverdi: snitt og standardavvik for dagene før `til`."""
    s = serie.loc[(serie.index < til) & (serie.index >= til - pd.Timedelta(days=dager))].dropna()
    if len(s) < min_n:
        return None
    return {"snitt": s.mean(), "sd": s.std(ddof=1) if len(s) > 1 else 0, "n": len(s)}


def siste(serie: pd.Series):
    s = serie.dropna()
    return (s.index[-1], s.iloc[-1]) if not s.empty else (None, None)


def snitt_siste(serie: pd.Series, dager: int, til: pd.Timestamp | None = None):
    til = til or serie.index.max()
    s = serie.loc[serie.index > til - pd.Timedelta(days=dager)].dropna()
    return s.mean() if len(s) >= max(2, dager // 3) else None


def trend(serie: pd.Series, dager: int = 21):
    """Retning siste periode: stigende/synkende/stabil (lineær stigning vs. variasjon)."""
    s = serie.loc[serie.index > serie.index.max() - pd.Timedelta(days=dager)].dropna()
    if len(s) < 7:
        return None
    x = (s.index - s.index[0]).days.values.astype(float)
    stigning = np.polyfit(x, s.values, 1)[0] * dager
    sd = s.std() or 1e-9
    if abs(stigning) < 0.5 * sd:
        return "stabil"
    return "stigende" if stigning > 0 else "synkende"


# ------------------------------------------------------------------ beredskap

NIVAER = {
    "Svært god": ("Klar for hard trening", "bra"),
    "God": ("Normal trening", "bra"),
    "Moderat": ("Vurder å justere intensiteten", "obs"),
    "Lav": ("Prioriter restitusjon", "lav"),
}


def _garmin_niva(score):
    if score >= 75:
        return "Svært god"
    if score >= 50:
        return "God"
    if score >= 25:
        return "Moderat"
    return "Lav"


def dagens_status(d: Data) -> dict:
    """Bygger dagens beredskap og en tekstlig analyse fra faktiske målinger."""
    dag = d.dag
    i_dag = dag.index.max()
    faktorer, setninger = [], []

    # HRV
    if d.har("hrv_natt"):
        t, v = siste(dag["hrv_natt"])
        if t is not None and (i_dag - t).days <= 1:
            status = str(dag.loc[t].get("hrv_status") or "").upper()
            lav, hoy = dag.loc[t].get("hrv_normal_lav"), dag.loc[t].get("hrv_normal_hoy")
            if pd.notna(lav) and pd.notna(hoy):
                if v < lav:
                    faktorer.append(-2)
                    setninger.append(f"HRV i natt ({v:.0f} ms) var under ditt normalområde ({lav:.0f}–{hoy:.0f} ms).")
                elif v > hoy:
                    faktorer.append(0)
                    setninger.append(f"HRV i natt ({v:.0f} ms) var over normalområdet, noe som også kan skyldes stress eller sykdom.")
                else:
                    faktorer.append(1)
                    setninger.append(f"HRV i natt ({v:.0f} ms) ligger innenfor normalområdet ditt.")
            else:
                n = norm(dag["hrv_natt"], t)
                if n and n["sd"]:
                    z = (v - n["snitt"]) / n["sd"]
                    faktorer.append(1 if z > -0.5 else (-1 if z > -1.5 else -2))
                    retning = "over" if z > 0.5 else "under" if z < -0.5 else "på nivå med"
                    setninger.append(f"HRV i natt ({v:.0f} ms) er {retning} 30-dagers snittet ({n['snitt']:.0f} ms).")
            if status in ("UNBALANCED", "LOW", "POOR"):
                setninger.append(f"Garmin vurderer HRV-statusen som «{_hrv_status_norsk(status)}».")

    # Hvilepuls
    if d.har("hvilepuls"):
        t, v = siste(dag["hvilepuls"])
        n = norm(dag["hvilepuls"], t) if t is not None else None
        if n and (i_dag - t).days <= 1:
            diff = v - n["snitt"]
            if diff >= 5:
                faktorer.append(-2)
                setninger.append(f"Hvilepulsen ({v:.0f}) er {diff:.0f} slag over normalen din.")
            elif diff >= 3:
                faktorer.append(-1)
                setninger.append(f"Hvilepulsen ({v:.0f}) ligger noe over normalen ({n['snitt']:.0f}).")
            elif diff <= -3:
                faktorer.append(1)
                setninger.append(f"Hvilepulsen ({v:.0f}) er lavere enn normalen din ({n['snitt']:.0f}).")
            else:
                faktorer.append(1 if diff <= 0 else 0)
                setninger.append(f"Hvilepulsen ({v:.0f}) er normal.")

    # Søvn
    if d.har("sovn_timer"):
        t, v = siste(dag["sovn_timer"].replace(0, np.nan))
        snitt7 = snitt_siste(dag["sovn_timer"].replace(0, np.nan).loc[:t - pd.Timedelta(days=1)], 7) if t is not None else None
        if t is not None and (i_dag - t).days <= 1 and v:
            t_min = f"{int(v)} t {int(round((v % 1) * 60))} min"
            if v < 6:
                faktorer.append(-2)
                setninger.append(f"Søvnen var kort ({t_min}).")
            elif snitt7 and v < snitt7 - 0.75:
                faktorer.append(-1)
                setninger.append(f"Søvnlengden ({t_min}) var lavere enn snittet de siste syv dagene ({_k(snitt7, '.1f')} t).")
            else:
                faktorer.append(1 if v >= 7.5 else 0)
                setninger.append(f"Du sov {t_min}.")
    if d.har("sovn_score"):
        t, v = siste(dag["sovn_score"])
        if t is not None and (i_dag - t).days <= 1:
            faktorer.append(-1 if v < 60 else (1 if v >= 80 else 0))

    # Belastning
    if d.har("acwr"):
        t, v = siste(dag["acwr"])
        if t is not None and (i_dag - t).days <= 2:
            if v > 1.5:
                faktorer.append(-2)
                setninger.append(f"Akutt belastning er høy i forhold til den kroniske (forhold {_k(v, '.2f')}).")
            elif v > 1.3:
                faktorer.append(-1)
                setninger.append(f"Belastningen har økt raskt den siste uken (forhold {_k(v, '.2f')}).")
            elif v < 0.8:
                setninger.append(f"Belastningen siste uke er lav i forhold til de siste fire ukene (forhold {_k(v, '.2f')}).")

    # Gårsdagens trening
    i_gaar = i_dag - pd.Timedelta(days=1)
    if not d.okter.empty:
        g = d.okter[d.okter["dato"] == i_gaar]
        if not g.empty:
            setninger.append("I går: " + ", ".join(
                f"{r.sport.lower()} {r.minutter:.0f} min" for r in g.itertuples()) + ".")
            if "okt_belastning" in dag and dag["okt_belastning"].notna().sum() > 20:
                terskel = dag.loc[dag["okt_belastning"] > 0, "okt_belastning"].quantile(0.85)
                if dag.loc[i_gaar, "okt_belastning"] >= terskel:
                    faktorer.append(-1)

    # Nivå: Garmin-beredskap foran egen beregning
    kilde, score = None, None
    if d.har("beredskap_score"):
        t, v = siste(dag["beredskap_score"])
        if t is not None and (i_dag - t).days <= 1:
            niva, kilde, score = _garmin_niva(v), "Garmin", v
    har_hrv = any("HRV" in x for x in setninger)
    if kilde is None:
        if len(faktorer) >= 2:
            s = sum(faktorer)
            niva = "Svært god" if s >= 2 else "God" if s >= 0 else "Moderat" if s >= -2 else "Lav"
            if niva == "Svært god" and not har_hrv:
                niva = "God"  # uten HRV er grunnlaget for svakt til å anbefale hard trening
            kilde = "Beregnet"
        else:
            niva = None

    anbefaling = {
        "Svært god": "Kroppen ser godt restituert ut. Dagen egner seg for en hard økt, for eksempel terskel eller intervaller.",
        "God": "Ingenting i målingene tilsier at du bør avvike fra planen.",
        "Moderat": "Vurder en rolig aerob økt i dag, og evaluer formen før en eventuell kveldsøkt.",
        "Lav": "Prioriter restitusjon: hvile eller svært rolig aktivitet.",
    }.get(niva, "")

    return {"niva": niva, "kilde": kilde, "score": score, "setninger": setninger, "har_hrv": har_hrv,
            "anbefaling": anbefaling, "dato": i_dag}


def _hrv_status_norsk(s: str) -> str:
    return {"BALANCED": "balansert", "UNBALANCED": "ubalansert", "LOW": "lav", "POOR": "svært lav"}.get(s.upper(), s.lower())


# ------------------------------------------------------------------ trening

def uke(df: pd.DataFrame, kol="dato"):
    return df[kol].dt.to_period("W-SUN").dt.start_time


def ukevolum(d: Data, uker: int = 12) -> pd.DataFrame:
    if d.okter.empty:
        return pd.DataFrame()
    ok = d.okter.copy()
    ok["uke"] = uke(ok)
    fra = ok["uke"].max() - pd.Timedelta(weeks=uker - 1)
    t = ok[ok["uke"] >= fra].pivot_table(index="uke", columns="sport", values="minutter", aggfunc="sum").fillna(0) / 60
    alle = pd.date_range(fra, ok["uke"].max(), freq="W-MON")
    return t.reindex(alle, fill_value=0)


def treningsdager_rad(d: Data) -> int:
    """Antall sammenhengende treningsdager fram til i dag."""
    s = d.dag["okter"].fillna(0)[::-1]
    n = 0
    for v in s:
        if v > 0:
            n += 1
        else:
            break
    return n


# ------------------------------------------------------------------ innsikter

def innsikter(d: Data) -> list[dict]:
    """Automatiske innsikter. Hver innsikt har et minstekrav til datagrunnlag."""
    ut = []
    dag, ok = d.dag, d.okter
    if ok.empty:
        return ut
    i_dag = dag.index.max()

    # 1. Volumutvikling siste 4 uker vs. 4 uker før, og kroppens respons
    a = dag.loc[dag.index > i_dag - pd.Timedelta(days=28)]
    b = dag.loc[(dag.index <= i_dag - pd.Timedelta(days=28)) & (dag.index > i_dag - pd.Timedelta(days=56))]
    if len(b) >= 28 and b["trening_min"].sum() > 0:
        endr = (a["trening_min"].sum() / b["trening_min"].sum() - 1) * 100
        deler = [f"De siste fire ukene har treningsvolumet {'økt' if endr > 0 else 'falt'} med "
                 f"{abs(endr):.0f} % ({_k(a['trening_min'].sum() / 60, '.1f')} t mot {_k(b['trening_min'].sum() / 60, '.1f')} t)."]
        tolkning = []
        for kol, navn, enhet, toleranse in [("hrv_natt", "HRV", "ms", 3), ("hvilepuls", "Hvilepulsen", "slag", 2)]:
            if d.har(kol) and a[kol].notna().sum() >= 14 and b[kol].notna().sum() >= 14:
                diff = a[kol].mean() - b[kol].mean()
                if abs(diff) < toleranse:
                    deler.append(f"{navn} har samtidig holdt seg stabil ({_k(diff, '+.1f')} {enhet}).")
                    tolkning.append("stabil")
                else:
                    deler.append(f"{navn} har endret seg med {_k(diff, '+.1f')} {enhet}.")
                    tolkning.append("hrv_ned" if kol == "hrv_natt" and diff < 0 else
                                    "puls_opp" if kol == "hvilepuls" and diff > 0 else "positiv")
        if endr > 5 and tolkning and all(x in ("stabil", "positiv") for x in tolkning):
            deler.append("Det tyder på at du foreløpig tolererer økningen godt.")
        elif endr > 5 and any(x in ("hrv_ned", "puls_opp") for x in tolkning):
            deler.append("Kroppen viser tegn til belastning; følg med på restitusjonen de neste dagene.")
        ut.append({"tittel": "Treningsvolum og respons", "tekst": " ".join(deler), "grunnlag": "56 dager"})

    # 2. HRV uken etter uker med høyt volum
    if d.har("hrv_natt"):
        u = dag.resample("W-SUN").agg({"trening_min": "sum", "hrv_natt": "mean"})
        u["hrv_neste"] = u["hrv_natt"].shift(-1)
        u = u.dropna(subset=["hrv_neste"])
        u = u[u["trening_min"] > 0]
        if len(u) >= 8:
            grense = u["trening_min"].quantile(0.75)
            hoy, rest = u[u["trening_min"] >= grense], u[u["trening_min"] < grense]
            if len(hoy) >= 3 and len(rest) >= 3:
                diff = hoy["hrv_neste"].mean() - rest["hrv_neste"].mean()
                tekst = (f"I ukene etter dine {len(hoy)} tyngste treningsuker (over {_k(grense / 60, '.1f')} t) var HRV i snitt "
                         f"{hoy['hrv_neste'].mean():.0f} ms, mot {rest['hrv_neste'].mean():.0f} ms etter øvrige uker ({_k(diff, '+.1f')} ms).")
                tekst += (" Forskjellen er liten." if abs(diff) < 3 else
                          " HRV ser ut til å falle etter tunge uker." if diff < 0 else
                          " HRV har ikke falt etter tunge uker.")
                ut.append({"tittel": "HRV etter tunge uker", "tekst": tekst, "grunnlag": f"{len(u)} uker"})

    # 3. Hvilepuls morgenen etter harde økter
    if d.har("hvilepuls") and ("te_anaerob" in ok or "te_type" in ok):
        hard = pd.Series(False, index=ok.index)
        if "te_anaerob" in ok:
            hard |= ok["te_anaerob"].fillna(0) >= 2.5
        if "te_type" in ok:
            hard |= ok["te_type"].astype(str).str.upper().isin(["LACTATE_THRESHOLD", "VO2MAX", "TEMPO", "ANAEROBIC_CAPACITY"])
        harde_dager = set(ok.loc[hard, "dato"])
        treningsdager = set(ok["dato"])
        rhr_neste = dag["hvilepuls"].shift(-1)
        h = rhr_neste[rhr_neste.index.isin(harde_dager)].dropna()
        r = rhr_neste[rhr_neste.index.isin(treningsdager - harde_dager)].dropna()
        if len(h) >= 5 and len(r) >= 5:
            diff = h.mean() - r.mean()
            tekst = (f"Morgenen etter {len(h)} harde økter (terskel/VO2 maks/anaerob) var hvilepulsen i snitt "
                     f"{_k(h.mean(), '.1f')}, mot {_k(r.mean(), '.1f')} etter rolige treningsdager ({_k(diff, '+.1f')} slag).")
            tekst += " Ingen tydelig forskjell." if abs(diff) < 1 else (
                " Hvilepulsen pleier å stige etter harde økter." if diff > 0 else "")
            ut.append({"tittel": "Hvilepuls etter harde økter", "tekst": tekst, "grunnlag": f"{len(h) + len(r)} dager"})

    # 4. Søvn over 8 timer og dagen etter
    if d.har("sovn_timer"):
        sovn = dag["sovn_timer"].replace(0, np.nan)
        for kol, navn, enhet in [("beredskap_score", "treningsberedskap", ""), ("hrv_natt", "HRV", " ms")]:
            if not d.har(kol):
                continue
            # søvn registreres på datoen man våkner; samme dato = morgenen etter
            par = pd.DataFrame({"sovn": sovn, "y": dag[kol]}).dropna()
            lang, kort = par[par["sovn"] >= 8], par[par["sovn"] < 7]
            if len(lang) >= 5 and len(kort) >= 5:
                diff = lang["y"].mean() - kort["y"].mean()
                ut.append({"tittel": "Søvnlengde og morgenen etter",
                           "tekst": f"Etter netter med over 8 timers søvn ({len(lang)} netter) var {navn} i snitt "
                                    f"{lang['y'].mean():.0f}{enhet}, mot {kort['y'].mean():.0f}{enhet} etter netter under 7 timer "
                                    f"({len(kort)} netter), en forskjell på {diff:+.0f}{enhet}.",
                           "grunnlag": f"{len(par)} netter"})
                break

    # 5. Dobbeltøkter flere dager på rad
    if d.har("hrv_natt") or d.har("hvilepuls"):
        dobbel = (dag["okter"] >= 2).astype(int)
        grp = (dobbel != dobbel.shift()).cumsum()
        rekker = dobbel.groupby(grp).agg(["sum", "size"])
        slutt = [dobbel[grp == g].index[-1] for g, r in rekker.iterrows() if r["sum"] >= 2 and r["sum"] == r["size"]]
        if len(slutt) >= 3:
            deler = [f"Du har hatt {len(slutt)} perioder med to økter daglig i minst to dager på rad."]
            for kol, navn, enhet in [("hrv_natt", "HRV", "ms"), ("hvilepuls", "hvilepulsen", "slag")]:
                if d.har(kol):
                    avvik = []
                    for t in slutt:
                        n = norm(dag[kol], t - pd.Timedelta(days=2), 30)
                        nest = t + pd.Timedelta(days=1)
                        if n and nest in dag.index and pd.notna(dag.loc[nest, kol]):
                            avvik.append(dag.loc[nest, kol] - n["snitt"])
                    if len(avvik) >= 3:
                        deler.append(f"Morgenen etter var {navn} i snitt {_k(np.mean(avvik), '+.1f')} {enhet} fra normalen din.")
            if len(deler) > 1:
                ut.append({"tittel": "Dobbeltøkter på rad", "tekst": " ".join(deler), "grunnlag": f"{len(slutt)} perioder"})

    # 6. VO2 maks og volum per måned
    for kol, sportnavn in [("vo2max_lop", "løp"), ("vo2max_sykkel", "sykkel")]:
        if d.har(kol):
            m = dag.resample("MS").agg({kol: "last", "trening_min": "sum"}).dropna()
            if len(m) >= 4:
                m["endring"] = m[kol].diff()
                m = m.dropna()
                hoy = m[m["trening_min"] >= m["trening_min"].median()]
                lav = m[m["trening_min"] < m["trening_min"].median()]
                if len(hoy) >= 2 and len(lav) >= 2:
                    ut.append({"tittel": f"VO2 maks ({sportnavn}) og treningsvolum",
                               "tekst": f"I måneder med mest trening endret VO2 maks for {sportnavn} seg i snitt "
                                        f"{_k(hoy['endring'].mean(), '+.1f')}, mot {_k(lav['endring'].mean(), '+.1f')} i måneder med mindre trening.",
                               "grunnlag": f"{len(m)} måneder"})

    # 7. Beste periode (4-ukers blokker) for VO2 maks
    for kol, sportnavn in [("vo2max_lop", "løp"), ("vo2max_sykkel", "sykkel")]:
        if d.har(kol) and (dag.index.max() - dag.index.min()).days >= 120:
            blokk = dag.resample("28D").agg({kol: ["first", "last"], "trening_min": "sum"}).dropna()
            if len(blokk) >= 4:
                blokk.columns = ["fra", "til", "min"]
                blokk["endr"] = blokk["til"] - blokk["fra"]
                best = blokk["endr"].idxmax()
                if blokk.loc[best, "endr"] > 0:
                    rad = blokk.loc[best]
                    snitt_t = blokk["min"].mean() / 60 / 4
                    ut.append({"tittel": f"Beste utviklingsperiode ({sportnavn})",
                               "tekst": f"Perioden som startet {best:%d.%m.%Y} ga størst økning i VO2 maks for {sportnavn} "
                                        f"({_k(rad['endr'], '+.1f')}). Da trente du i snitt {_k(rad['min'] / 60 / 4, '.1f')} t per uke, "
                                        f"mot {_k(snitt_t, '.1f')} t ellers.",
                               "grunnlag": f"{len(blokk)} perioder"})
    return ut
