"""
Personlig helse- og prestasjonssenter for triatlon.
Start med:  streamlit run prestasjonssenter.py
"""
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

import ps_data as P

MAPPE = Path(__file__).parent

# ------------------------------------------------------------------ uttrykk

FARGE = {
    "bg": "#12171F", "flate": "#18202A", "linje": "#263040", "tekst": "#E4E8EE", "dempet": "#8A94A6",
    "Svømming": "#3FB6C9", "Sykling": "#8A93F6", "Løping": "#E58BB4", "Styrke": "#A7B0BF", "Annet": "#5D6778",
    "bra": "#4CB782", "obs": "#E3B341", "lav": "#E5534B", "aksent": "#9FB4D9",
}

st.set_page_config(page_title="Prestasjonssenter", page_icon="🏊", layout="wide")

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Semi+Condensed:wght@500;600&display=swap');
html, body, [class*="st-"], .stMarkdown, button, input {{ font-family: 'Barlow', system-ui, sans-serif; }}
h1, h2, h3, h4 {{ font-family: 'Barlow Semi Condensed', 'Barlow', sans-serif !important; font-weight: 600 !important; letter-spacing: 0.01em; }}
h1 {{ font-size: 1.9rem !important; }}
h3 {{ font-size: 1.15rem !important; margin-top: 1.4rem !important; color: {FARGE['tekst']}; }}
.block-container {{ padding-top: 3.2rem; max-width: 1280px; }}
.num {{ font-variant-numeric: tabular-nums; }}
.dempet {{ color: {FARGE['dempet']}; }}
.kilde {{ display:inline-block; font-size:0.68rem; padding:1px 6px; border-radius:3px; margin-left:6px;
         border:1px solid {FARGE['linje']}; color:{FARGE['dempet']}; vertical-align:middle; }}
.kilde.ber {{ border-style:dashed; }}

.status {{ display:grid; grid-template-columns: minmax(220px, 300px) 1fr; gap: 2rem; padding: 1.4rem 1.6rem;
          background:{FARGE['flate']}; border-radius:10px; border-left:4px solid var(--s); margin: 0.6rem 0 1.4rem; }}
.status .niva {{ font-family:'Barlow Semi Condensed'; font-size:2rem; font-weight:600; line-height:1.1; color:var(--s); }}
.status .handling {{ font-size:1.02rem; margin-top:0.2rem; }}
.status .meta {{ font-size:0.8rem; color:{FARGE['dempet']}; margin-top:0.7rem; }}
.status .analyse {{ font-size:1rem; line-height:1.6; max-width: 70ch; }}
.status .analyse p {{ margin: 0 0 0.5rem; }}
.status .analyse .anbefaling {{ color:{FARGE['tekst']}; font-weight:500; }}

.stripe {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(135px, 1fr)); border-top:1px solid {FARGE['linje']};
          border-bottom:1px solid {FARGE['linje']}; margin: 0.4rem 0 1rem; }}
.stripe > div {{ padding: 0.8rem 0.9rem; border-right:1px solid {FARGE['linje']}; }}
.stripe > div:last-child {{ border-right:none; }}
.stripe .l {{ font-size:0.78rem; color:{FARGE['dempet']}; }}
.stripe .v {{ font-size:1.35rem; font-weight:500; font-variant-numeric: tabular-nums; margin-top:2px; }}
.stripe .v small {{ font-size:0.8rem; color:{FARGE['dempet']}; font-weight:400; }}
.stripe .s {{ font-size:0.76rem; color:{FARGE['dempet']}; margin-top:2px; }}
.na {{ color:{FARGE['dempet']}; font-size:0.95rem !important; }}

table.tab {{ width:100%; border-collapse:collapse; font-variant-numeric: tabular-nums; font-size:0.92rem; }}
table.tab th {{ text-align:right; font-weight:500; color:{FARGE['dempet']}; padding:6px 10px; border-bottom:1px solid {FARGE['linje']}; font-size:0.8rem; }}
table.tab td {{ text-align:right; padding:7px 10px; border-bottom:1px solid {FARGE['linje']}55; }}
table.tab th:first-child, table.tab td:first-child {{ text-align:left; }}
.tabwrap {{ overflow-x:auto; }}

.innsikt {{ padding: 1rem 0 1.1rem; border-bottom:1px solid {FARGE['linje']}; max-width: 78ch; }}
.innsikt h4 {{ margin:0 0 0.35rem; font-size:1.05rem; }}
.innsikt p {{ margin:0; line-height:1.6; }}
.innsikt .g {{ font-size:0.78rem; color:{FARGE['dempet']}; margin-top:0.35rem; }}

.dag {{ font-size:0.8rem; color:{FARGE['dempet']}; margin-bottom:2px; }}
.dag.idag {{ color:{FARGE['tekst']}; font-weight:600; }}
div[data-testid="stColumn"] button p {{ font-size:0.78rem; line-height:1.25; text-align:left; }}

@media (max-width: 760px) {{
  .status {{ grid-template-columns: 1fr; gap: 0.8rem; padding: 1.1rem; }}
  .stripe > div {{ border-right:none; border-bottom:1px solid {FARGE['linje']}55; }}
  .block-container {{ padding-left: 1rem; padding-right: 1rem; }}
}}
@media (prefers-reduced-motion: reduce) {{ * {{ transition:none !important; animation:none !important; }} }}
</style>
""", unsafe_allow_html=True)


def kilde(k):
    return f'<span class="kilde{" ber" if k == "Beregnet" else ""}">{k}</span>' if k else ""


def fig_stil(fig, h=300, legende=True):
    fig.update_layout(
        height=h, margin=dict(l=4, r=4, t=28, b=4), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Barlow, system-ui, sans-serif", color=FARGE["dempet"], size=12),
        hovermode="x unified", showlegend=legende, bargap=0.25,
        legend=dict(orientation="h", y=1.08, x=0, bgcolor="rgba(0,0,0,0)", font=dict(size=11)),
        hoverlabel=dict(bgcolor=FARGE["flate"], bordercolor=FARGE["linje"], font_color=FARGE["tekst"]),
    )
    fig.update_xaxes(showgrid=False, linecolor=FARGE["linje"], title=None)
    fig.update_yaxes(gridcolor=FARGE["linje"], zeroline=False, title=None)
    return fig


def vis(fig, h=300, legende=True):
    st.plotly_chart(fig_stil(fig, h, legende), width="stretch", theme=None,
                    config={"displayModeBar": False})


def t_min(minutter):
    if minutter is None or pd.isna(minutter):
        return "–"
    t, m = divmod(int(round(minutter)), 60)
    return f"{t} t {m:02d} min" if t else f"{m} min"


def tempo(sek_per_enhet):
    if sek_per_enhet is None or pd.isna(sek_per_enhet) or sek_per_enhet <= 0:
        return "–"
    m, s = divmod(int(round(sek_per_enhet)), 60)
    return f"{m}:{s:02d}"


def tall(v, d=0, enhet=""):
    if v is None or pd.isna(v):
        return "–"
    return f"{v:,.{d}f}".replace(",", " ").replace(".", ",") + (f" <small>{enhet}</small>" if enhet else "")


def stripe(felter):
    """felter: liste av (etikett, verdi_html, undertekst, kilde)"""
    celler = []
    for l, v, s, k in felter:
        tom = v in ("–", None)
        celler.append(f'<div><div class="l">{l}{kilde(k) if not tom else ""}</div>'
                      f'<div class="v{" na" if tom else ""}">{"Ikke tilgjengelig" if tom else v}</div>'
                      f'<div class="s">{s or "&nbsp;"}</div></div>')
    st.markdown(f'<div class="stripe">{"".join(celler)}</div>', unsafe_allow_html=True)


UKEDAG = ["mandag", "tirsdag", "onsdag", "torsdag", "fredag", "lørdag", "søndag"]
MND = ["januar", "februar", "mars", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "desember"]


def dato_norsk(t, klokke=False):
    tekst = f"{UKEDAG[t.weekday()]} {t.day}. {MND[t.month - 1]} {t.year}"
    return (tekst + (f" kl. {t:%H:%M}" if klokke else "")).capitalize()


def utilgjengelig(tekst):
    st.markdown(f'<p class="dempet">{tekst}</p>', unsafe_allow_html=True)


# ------------------------------------------------------------------ data

@st.cache_data(ttl=600)
def hent():
    return P.last_alt()


with st.sidebar:
    st.markdown("### Data")
    if st.button("Hent nye data", width="stretch", type="primary"):
        feil = []
        with st.spinner("Henter fra Garmin …"):
            for script in ["hent_data.py", "hent_ekstra.py"]:
                if (MAPPE / script).exists():
                    r = subprocess.run([sys.executable, str(MAPPE / script), "--dager", "7"],
                                       capture_output=True, text=True, cwd=MAPPE)
                    if r.returncode != 0:
                        feil.append((script, r.stdout[-800:] + r.stderr[-800:]))
        st.cache_data.clear()
        if feil:
            for s, tekst in feil:
                st.error(f"{s} feilet. Kjør den i terminalen for detaljer.")
                st.code(tekst)
        else:
            st.success("Data oppdatert.")
    f = MAPPE / "data" / "daglig.csv"
    if f.exists():
        st.caption(f"Sist hentet {datetime.fromtimestamp(f.stat().st_mtime):%d.%m.%Y kl. %H:%M}")
    st.markdown("### Kilder")
    st.markdown(f'{kilde("Garmin")} målt eller beregnet av Garmin<br>{kilde("Beregnet")} utledet her fra dine Garmin-data',
                unsafe_allow_html=True)

D = hent()
if D is None:
    st.title("Prestasjonssenter")
    st.info("Fant ingen data. Kjør `python hent_data.py` og `python hent_ekstra.py` i terminalen, og last siden på nytt.")
    st.stop()

DAG, OK = D.dag, D.okter
I_DAG = DAG.index.max()


def periode(df, dager, kol=None):
    fra = I_DAG - pd.Timedelta(days=dager - 1)
    if kol:
        return df[df[kol] >= fra]
    return df.loc[df.index >= fra]


def hint_ekstra():
    if not D.har_ekstra:
        st.info("Mange målinger her krever tilleggsdataene. Kjør `python hent_ekstra.py --dager 365` i terminalen.")


# ================================================================== OVERSIKT

def oversikt():
    st.title("Oversikt")
    st.caption(dato_norsk(I_DAG))
    s = P.dagens_status(D)

    if s["niva"]:
        handling, tone = P.NIVAER[s["niva"]]
        meta = (f"Garmin Training Readiness: {s['score']:.0f} av 100" if s["kilde"] == "Garmin"
                else "Beregnet fra HRV, hvilepuls, søvn og belastning" if s["har_hrv"]
                else "Beregnet uten HRV, fra hvilepuls, søvn og belastning. Vurderingen blir sikrere når HRV er hentet.")
        analyse = "".join(f"<p>{x}</p>" for x in s["setninger"])
        st.markdown(f"""
        <div class="status" style="--s:{FARGE[tone]}">
          <div><div class="niva">{s['niva']}</div><div class="handling">{handling}</div>
               <div class="meta">Treningsberedskap {kilde(s['kilde'])}<br>{meta}</div></div>
          <div class="analyse">{analyse}<p class="anbefaling">{s['anbefaling']}</p></div>
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="status" style="--s:{FARGE["linje"]}"><div><div class="niva" style="color:{FARGE["dempet"]}">Ukjent</div>'
                    f'<div class="handling">For lite data i dag</div></div><div class="analyse"><p>Beredskap krever minst to av '
                    f'HRV, hvilepuls, søvn og belastning fra i natt.</p>{"".join(f"<p>{x}</p>" for x in s["setninger"])}</div></div>',
                    unsafe_allow_html=True)

    def sist(kol):
        return P.siste(DAG[kol])[1] if D.har(kol) else None

    hrv, hrv7 = sist("hrv_natt"), sist("hrv_7d")
    rhr = sist("hvilepuls")
    rhr_n = P.norm(DAG["hvilepuls"], I_DAG + pd.Timedelta(days=1)) if D.har("hvilepuls") else None
    sovn = sist("sovn_timer")
    sovn7 = P.snitt_siste(DAG["sovn_timer"].replace(0, np.nan), 7) if D.har("sovn_timer") else None
    rest = sist("restitusjonstid_min")
    acwr = sist("acwr")
    akutt = sist("belastning_akutt")
    stripe([
        ("HRV i natt", tall(hrv, 0, "ms"), f"7 d: {hrv7:.0f} ms" if hrv7 else "", "Garmin"),
        ("Hvilepuls", tall(rhr, 0, "bpm"), f"Normal {rhr_n['snitt']:.0f}" if rhr_n else "", "Garmin"),
        ("Søvnscore", tall(sist("sovn_score")), "", "Garmin"),
        ("Søvn", t_min(sovn * 60) if sovn else "–", f"7 d: {P._k(sovn7, '.1f')} t" if sovn7 else "", "Garmin"),
        ("Restitusjonstid", tall(rest / 60 if rest else None, 0, "t"), "", "Garmin"),
        ("Akutt belastning", tall(akutt), f"Akutt/kronisk {P._k(acwr, '.2f')}" if acwr else "", D.last_kilde),
    ])

    v, h = st.columns([3, 2], gap="large")
    with v:
        st.markdown("### Siste 14 dager")
        p = periode(DAG, 14)
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        if not OK.empty:
            o = periode(OK, 14, "dato")
            for sp in P.SPORTER:
                ss = o[o["sport"] == sp].groupby("dato")["minutter"].sum()
                if not ss.empty:
                    fig.add_bar(x=ss.index, y=ss.values, name=sp, marker_color=FARGE[sp], secondary_y=False,
                                hovertemplate="%{y:.0f} min")
        if D.har("hrv_natt"):
            fig.add_scatter(x=p.index, y=p["hrv_natt"], name="HRV", mode="lines+markers",
                            line=dict(color=FARGE["tekst"], width=1.6), marker=dict(size=4), secondary_y=True,
                            hovertemplate="%{y:.0f} ms")
        fig.update_layout(barmode="stack")
        fig.update_yaxes(title_text="min", secondary_y=False)
        fig.update_yaxes(showgrid=False, secondary_y=True)
        vis(fig, 300)
    with h:
        st.markdown("### Denne uken")
        if OK.empty:
            utilgjengelig("Ingen økter registrert.")
        else:
            mandag = I_DAG - pd.Timedelta(days=I_DAG.weekday())
            denne = OK[OK["dato"] >= mandag]
            forrige = OK[(OK["dato"] >= mandag - pd.Timedelta(days=7)) & (OK["dato"] < mandag)]
            rader = ""
            for sp in P.SPORTER:
                a, b = denne.loc[denne["sport"] == sp, "minutter"].sum(), forrige.loc[forrige["sport"] == sp, "minutter"].sum()
                if a or b:
                    rader += (f'<tr><td><span style="color:{FARGE[sp]}">●</span> {sp}</td><td>{t_min(a)}</td>'
                              f'<td class="dempet">{t_min(b)}</td></tr>')
            rader += (f'<tr><td><b>Totalt</b></td><td><b>{t_min(denne["minutter"].sum())}</b></td>'
                      f'<td class="dempet">{t_min(forrige["minutter"].sum())}</td></tr>')
            st.markdown(f'<div class="tabwrap"><table class="tab"><tr><th></th><th>Denne uken</th><th>Forrige uke</th></tr>{rader}'
                        f'</table></div>', unsafe_allow_html=True)
            st.markdown(f'<p class="dempet" style="margin-top:.6rem">{len(denne)} økter på {denne["dato"].nunique()} dager. '
                        f'{P.treningsdager_rad(D)} treningsdager på rad.</p>', unsafe_allow_html=True)

            if "int_lav_min" in OK:
                o7 = periode(OK, 7, "dato")
                lav, mod, hoy = o7["int_lav_min"].sum(), o7["int_mod_min"].sum(), o7["int_hoy_min"].sum()
                tot = lav + mod + hoy
                if tot:
                    st.markdown(f'<p class="dempet" style="margin:.8rem 0 .2rem">Intensitet siste 7 dager (pulssoner) {kilde("Garmin")}</p>',
                                unsafe_allow_html=True)
                    fig = go.Figure()
                    for navn, verdi, farge in [("Lav (sone 1–2)", lav, "#5C7A99"), ("Moderat (sone 3)", mod, "#9FB4D9"),
                                               ("Høy (sone 4–5)", hoy, "#E6EDF7")]:
                        fig.add_bar(y=[""], x=[verdi / tot * 100], name=navn, orientation="h", marker_color=farge,
                                    hovertemplate=f"{navn}: %{{x:.0f}} %<extra></extra>")
                    fig.update_layout(barmode="stack", hovermode="closest")
                    fig.update_xaxes(range=[0, 100], ticksuffix=" %", showgrid=False)
                    vis(fig, 110)

    st.markdown("### Gårsdagens trening")
    g = OK[OK["dato"] == I_DAG - pd.Timedelta(days=1)] if not OK.empty else OK
    if g.empty:
        utilgjengelig("Ingen økter i går.")
    else:
        rader = "".join(
            f'<tr><td><span style="color:{FARGE[r.sport]}">●</span> {r.navn}</td><td>{r.start:%H:%M}</td><td>{t_min(r.minutter)}</td>'
            f'<td>{tall(r.km, 1) if r.km else "–"} km</td><td>{tall(getattr(r, "snittpuls", None))}</td>'
            f'<td>{tall(getattr(r, "belastning", None))}</td></tr>' for r in g.itertuples())
        st.markdown(f'<div class="tabwrap"><table class="tab"><tr><th>Økt</th><th>Start</th><th>Varighet</th><th>Distanse</th>'
                    f'<th>Snittpuls</th><th>Belastning</th></tr>{rader}</table></div>', unsafe_allow_html=True)
    hint_ekstra()


# ================================================================== HELSE

HELSEMAL = [
    # kolonne, navn, enhet, desimaler, høyere er bedre (None = nøytral)
    ("hrv_natt", "HRV (natt)", "ms", 0, True),
    ("hrv_7d", "HRV 7-dagers snitt", "ms", 0, True),
    ("hvilepuls", "Hvilepuls", "bpm", 0, False),
    ("sovn_score", "Søvnscore", "", 0, True),
    ("sovn_timer", "Søvnlengde", "t", 1, True),
    ("resp_sovn", "Respirasjon (søvn)", "/min", 1, None),
    ("spo2_snitt", "SpO2", "%", 0, True),
    ("vekt_kg", "Vekt", "kg", 1, None),
    ("stress", "Stressnivå", "", 0, False),
    ("body_battery_maks", "Body Battery (maks)", "", 0, True),
]


def helse():
    st.title("Helse og restitusjon")
    hint_ekstra()
    tilgj = [m for m in HELSEMAL if D.har(m[0])]
    mangler = [m[1] for m in HELSEMAL if not D.har(m[0])]

    rader = ""
    for kol, navn, enhet, dec, bedre in tilgj:
        s = DAG[kol].replace(0, np.nan) if kol in ("sovn_timer", "vekt_kg") else DAG[kol]
        t, v = P.siste(s)
        n = P.norm(s, I_DAG + pd.Timedelta(days=1), 90, 14)
        tr = P.trend(s)
        pil = {"stigende": "↗ stigende", "synkende": "↘ synkende", "stabil": "→ stabil"}.get(tr, "–")
        avvik = ""
        if n and n["sd"] and v is not None:
            z = (v - n["snitt"]) / n["sd"]
            if abs(z) >= 1 and bedre is not None:
                god = (z > 0) == bedre
                avvik = f' <span style="color:{FARGE["bra"] if god else FARGE["obs"]}">●</span>'
        f = f"{{:.{dec}f}}"
        rader += (f'<tr><td>{navn} <span class="dempet">{enhet}</span></td>'
                  f'<td>{f.format(v) if v is not None else "–"}{avvik}</td>'
                  f'<td>{f.format(x) if (x := P.snitt_siste(s, 7)) is not None else "–"}</td>'
                  f'<td>{f.format(x) if (x := P.snitt_siste(s, 30)) is not None else "–"}</td>'
                  f'<td class="dempet">{f.format(n["snitt"]) if n else "–"}</td><td class="dempet">{pil}</td></tr>')
    if rader:
        st.markdown(f'<div class="tabwrap"><table class="tab"><tr><th>Måling</th><th>Siste</th><th>7 d</th><th>30 d</th>'
                    f'<th>Normal (90 d)</th><th>Trend 3 uker</th></tr>{rader}</table></div>', unsafe_allow_html=True)
        st.caption("● markerer siste verdi mer enn ett standardavvik fra normalen din: grønn i gunstig retning, gul i ugunstig. Alle målinger fra Garmin.")
    if mangler:
        st.caption("Ikke tilgjengelig fra klokken din ennå: " + ", ".join(mangler) + ".")

    if not tilgj:
        return
    st.markdown("### Utvikling")
    c1, c2 = st.columns([3, 1])
    with c1:
        valg = st.segmented_control("Måling", [m[1] for m in tilgj], default=tilgj[0][1], required=True,
                                    label_visibility="collapsed", key="helse_maal")
    with c2:
        dager = st.segmented_control("Periode", [30, 90, 365], default=90, required=True, format_func=lambda x: f"{x} d",
                                     label_visibility="collapsed", key="helse_per")
    kol, navn, enhet, dec, bedre = next(m for m in tilgj if m[1] == valg)
    s = DAG[kol].replace(0, np.nan) if kol in ("sovn_timer", "vekt_kg") else DAG[kol]
    p = periode(s.to_frame(), dager)[kol]
    fig = go.Figure()
    if kol in ("hrv_natt", "hrv_7d") and D.har("hrv_normal_lav"):
        b = periode(DAG[["hrv_normal_lav", "hrv_normal_hoy"]], dager).dropna()
        fig.add_scatter(x=b.index, y=b["hrv_normal_hoy"], line=dict(width=0), showlegend=False, hoverinfo="skip")
        fig.add_scatter(x=b.index, y=b["hrv_normal_lav"], fill="tonexty", fillcolor="rgba(159,180,217,0.12)",
                        line=dict(width=0), name="Garmins normalområde", hoverinfo="skip")
    else:
        n = P.norm(s, I_DAG + pd.Timedelta(days=1), 90, 14)
        if n:
            fig.add_hrect(y0=n["snitt"] - n["sd"], y1=n["snitt"] + n["sd"], fillcolor="rgba(159,180,217,0.10)", line_width=0)
            fig.add_hline(y=n["snitt"], line=dict(color=FARGE["aksent"], width=1, dash="dot"))
    fig.add_scatter(x=p.index, y=p, mode="markers", name="Daglig", marker=dict(size=5, color=FARGE["dempet"]),
                    hovertemplate=f"%{{y:.{dec}f}} {enhet}")
    fig.add_scatter(x=p.index, y=p.rolling(7, min_periods=3).mean(), mode="lines", name="7-dagers snitt",
                    line=dict(color=FARGE["tekst"], width=2), hovertemplate=f"%{{y:.{dec}f}}")
    vis(fig, 320)
    st.caption("Skravert felt: normalområdet ditt (Garmins HRV-baseline, ellers snitt ± ett standardavvik siste 90 dager).")

    if D.har("sovn_dyp"):
        st.markdown("### Søvnfaser")
        p = periode(DAG, min(dager, 90))
        fig = go.Figure()
        for k, n, c in [("sovn_dyp", "Dyp", "#4B5FA8"), ("sovn_rem", "REM", "#8A93F6"), ("sovn_lett", "Lett", "#5C7A99"),
                        ("sovn_vaaken", "Våken", "#3A4354")]:
            if k in p:
                fig.add_bar(x=p.index, y=p[k], name=n, marker_color=c, hovertemplate="%{y:.1f} t")
        fig.update_layout(barmode="stack")
        vis(fig, 260)


# ================================================================== TRENING

def trening():
    st.title("Trening")
    if OK.empty:
        utilgjengelig("Ingen økter registrert ennå.")
        return
    mandag = I_DAG - pd.Timedelta(days=I_DAG.weekday())
    mnd = I_DAG.replace(day=1)
    forr_mnd = (mnd - pd.Timedelta(days=1)).replace(day=1)
    u = OK[OK["dato"] >= mandag]
    fu = OK[(OK["dato"] >= mandag - pd.Timedelta(days=7)) & (OK["dato"] < mandag)]
    m = OK[OK["dato"] >= mnd]
    # sammenlign måneden med samme antall dager i forrige måned
    fm = OK[(OK["dato"] >= forr_mnd) & (OK["dato"] < forr_mnd + (I_DAG - mnd) + pd.Timedelta(days=1))]
    stripe([
        ("Denne uken", t_min(u["minutter"].sum()), f"Forrige uke {t_min(fu['minutter'].sum())}", "Garmin"),
        ("Denne måneden", t_min(m["minutter"].sum()), f"Samme periode forrige mnd {t_min(fm['minutter'].sum())}", "Garmin"),
        ("Økter (uke)", str(len(u)), f"Forrige uke {len(fu)}", None),
        ("Treningsdager (uke)", str(u["dato"].nunique()), f"Forrige uke {fu['dato'].nunique()}", None),
        ("Kalorier (uke)", tall(u["kalorier"].sum(), 0, "kcal") if "kalorier" in u else "–", "", "Garmin"),
    ])

    st.markdown("### Ukentlig volum")
    uker = st.segmented_control("Uker", [12, 26, 52], default=12, required=True, format_func=lambda x: f"{x} uker",
                                label_visibility="collapsed", key="tr_uker")
    v = P.ukevolum(D, uker)
    fig = go.Figure()
    for sp in [s for s in P.SPORTER if s in v]:
        fig.add_bar(x=v.index, y=v[sp], name=sp, marker_color=FARGE[sp], hovertemplate="%{y:.1f} t")
    if len(v) >= 4:
        fig.add_scatter(x=v.index, y=v.sum(axis=1).rolling(4, min_periods=2).mean(), name="4-ukers snitt",
                        line=dict(color=FARGE["tekst"], width=1.5, dash="dot"), hovertemplate="%{y:.1f} t")
    fig.update_layout(barmode="stack")
    fig.update_yaxes(ticksuffix=" t")
    vis(fig, 320)
    if len(v) >= 8:
        a, b = v.sum(axis=1).iloc[-4:].mean(), v.sum(axis=1).iloc[-8:-4].mean()
        if b:
            endr = (a / b - 1) * 100
            ord_ = "økt" if endr > 5 else "falt" if endr < -5 else "holdt seg stabilt"
            st.caption(f"Snittvolumet siste fire uker ({P._k(a, '.1f')} t/uke) har {ord_}"
                       f"{'' if abs(endr) <= 5 else f' med {abs(endr):.0f} %'} sammenlignet med de fire ukene før ({P._k(b, '.1f')} t/uke).")

    st.markdown("### Per aktivitet")
    dager = st.segmented_control("Periode", [7, 30, 90, 365], default=30, required=True, format_func=lambda x: f"{x} d",
                                 label_visibility="collapsed", key="tr_per")
    o = periode(OK, dager, "dato")
    rader = ""
    for sp in P.SPORTER:
        x = o[o["sport"] == sp]
        if x.empty:
            continue
        rader += (f'<tr><td><span style="color:{FARGE[sp]}">●</span> {sp}</td><td>{len(x)}</td><td>{t_min(x["minutter"].sum())}</td>'
                  f'<td>{tall(x["km"].sum(), 1) if sp != "Styrke" else "–"}</td><td>{tall(x["kalorier"].sum())}</td>'
                  f'<td>{tall(x["snittpuls"].mean()) if "snittpuls" in x else "–"}</td>'
                  f'<td>{tall(x["makspuls"].max()) if "makspuls" in x else "–"}</td>'
                  f'<td>{tall(x["belastning"].sum()) if "belastning" in x and x["belastning"].notna().any() else "–"}</td></tr>')
    st.markdown(f'<div class="tabwrap"><table class="tab"><tr><th>Aktivitet</th><th>Økter</th><th>Tid</th><th>Km</th><th>Kcal</th>'
                f'<th>Snittpuls</th><th>Makspuls</th><th>Belastning</th></tr>{rader}</table></div>', unsafe_allow_html=True)
    if "belastning_beregnet" in OK and OK["belastning_beregnet"].any():
        st.caption("Belastning er Garmins tall der det finnes; ellers beregnet som TRIMP fra snittpuls, hvilepuls og makspuls.")

    if "int_lav_min" in OK and OK["int_lav_min"].notna().any():
        st.markdown(f"### Intensitetsfordeling {kilde('Garmin')}", unsafe_allow_html=True)
        x = OK.copy()
        x["uke"] = P.uke(x)
        w = x[x["uke"] >= x["uke"].max() - pd.Timedelta(weeks=uker - 1)].groupby("uke")[["int_lav_min", "int_mod_min", "int_hoy_min"]].sum()
        andel = w.div(w.sum(axis=1).replace(0, np.nan), axis=0) * 100
        fig = go.Figure()
        for k, n, c in [("int_lav_min", "Lav (sone 1–2)", "#5C7A99"), ("int_mod_min", "Moderat (sone 3)", "#9FB4D9"),
                        ("int_hoy_min", "Høy (sone 4–5)", "#E6EDF7")]:
            fig.add_bar(x=andel.index, y=andel[k], name=n, marker_color=c, hovertemplate="%{y:.0f} %")
        fig.update_layout(barmode="stack")
        fig.update_yaxes(range=[0, 100], ticksuffix=" %")
        vis(fig, 260)
        tot = w.sum()
        if tot.sum():
            st.caption(f"Siste {uker} uker: {tot['int_lav_min'] / tot.sum() * 100:.0f} % lav, "
                       f"{tot['int_mod_min'] / tot.sum() * 100:.0f} % moderat, {tot['int_hoy_min'] / tot.sum() * 100:.0f} % høy intensitet (tid i pulssoner).")


# ================================================================== PRESTASJON

def linje(fig, x, y, navn, farge, punkter=True, hover="%{y:.1f}", **kw):
    fig.add_scatter(x=x, y=y, name=navn, mode="lines+markers" if punkter else "lines",
                    line=dict(color=farge, width=2), marker=dict(size=5), hovertemplate=hover, **kw)


def prestasjon():
    st.title("Prestasjonsutvikling")
    hint_ekstra()
    dager = st.segmented_control("Periode", [30, 90, 365], default=90, required=True, format_func=lambda x: f"{x} dager",
                                 label_visibility="collapsed", key="pr_per")
    p = periode(DAG, dager)
    o = periode(OK, dager, "dato") if not OK.empty else OK
    ter = D.terskler[D.terskler["dato"] >= I_DAG - pd.Timedelta(days=dager)] if not D.terskler.empty else D.terskler

    t1, t2, t3 = st.tabs(["Sykling", "Løping", "Svømming"])

    # ---------------- Sykling
    with t1:
        syk = o[o["sport"] == "Sykling"] if not o.empty else o
        ftp = ter.dropna(subset=["ftp"]) if "ftp" in ter else pd.DataFrame()
        vekt = P.siste(DAG["vekt_kg"])[1] if D.har("vekt_kg") else None
        ftp_sist = ftp["ftp"].iloc[-1] if not ftp.empty else None
        np_snitt = syk["np"].dropna() if "np" in syk else pd.Series(dtype=float)
        stripe([
            ("FTP", tall(ftp_sist, 0, "W"), f"{P._k(ftp_sist / vekt, '.2f')} W/kg" if ftp_sist and vekt else "", "Garmin"),
            ("VO2 maks sykkel", tall(P.siste(DAG["vo2max_sykkel"])[1] if D.har("vo2max_sykkel") else None, 0), "", "Garmin"),
            ("Sykkeltid", t_min(syk["minutter"].sum()) if not syk.empty else "–", f"{len(syk)} økter", "Garmin"),
            ("Snitt NP", tall(np_snitt.mean(), 0, "W") if not np_snitt.empty else "–", "Økter med effektmåler", "Garmin"),
        ])
        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown("### FTP og VO2 maks")
            if ftp.empty and not D.har("vo2max_sykkel"):
                utilgjengelig("FTP og VO2 maks for sykkel er ikke tilgjengelig. Det krever effektmåler og at Garmin har estimert verdiene.")
            else:
                fig = make_subplots(specs=[[{"secondary_y": True}]])
                if not ftp.empty:
                    linje(fig, ftp["dato"], ftp["ftp"], "FTP (W)", FARGE["Sykling"], hover="%{y:.0f} W", line_shape="hv")
                if D.har("vo2max_sykkel"):
                    linje(fig, p.index, p["vo2max_sykkel"], "VO2 maks", FARGE["tekst"], punkter=False, secondary_y=True)
                fig.update_yaxes(showgrid=False, secondary_y=True)
                vis(fig, 280)
        with c2:
            st.markdown("### Effekt per økt")
            if "snitteffekt" in syk and syk["snitteffekt"].notna().any():
                e = syk[syk["minutter"] >= 20]
                fig = go.Figure()
                fig.add_scatter(x=e["start"], y=e["snitteffekt"], mode="markers", name="Snitteffekt",
                                marker=dict(color=FARGE["dempet"], size=6), hovertemplate="%{y:.0f} W")
                if "np" in e and e["np"].notna().any():
                    fig.add_scatter(x=e["start"], y=e["np"], mode="markers", name="NP",
                                    marker=dict(color=FARGE["Sykling"], size=7), hovertemplate="%{y:.0f} W")
                vis(fig, 280)
            else:
                utilgjengelig("Ingen effektdata for sykkeløktene i perioden.")
        if not syk.empty and "snitteffekt" in syk and "snittpuls" in syk:
            e = syk[(syk["minutter"] >= 30) & syk["snitteffekt"].notna() & syk["snittpuls"].notna()]
            if len(e) >= 5:
                st.markdown(f"### Watt per hjerteslag {kilde('Beregnet')}", unsafe_allow_html=True)
                ef = (e["np"].fillna(e["snitteffekt"]) if "np" in e else e["snitteffekt"]) / e["snittpuls"]
                fig = go.Figure()
                fig.add_scatter(x=e["start"], y=ef, mode="markers", name="Økt", marker=dict(color=FARGE["dempet"], size=6),
                                hovertemplate="%{y:.2f} W/slag")
                fig.add_scatter(x=e["start"], y=ef.rolling(5, min_periods=3).mean(), name="Glidende snitt (5 økter)",
                                line=dict(color=FARGE["Sykling"], width=2), hovertemplate="%{y:.2f}")
                vis(fig, 240)
                st.caption("Effektivitetsfaktor (NP ÷ snittpuls) for økter over 30 min. Stigende verdi ved samme intensitet tyder på bedre aerob kapasitet, men påvirkes av øktens innhold, varme og dagsform.")

    # ---------------- Løping
    with t2:
        lop = o[o["sport"] == "Løping"] if not o.empty else o
        prog = D.prognoser[D.prognoser["dato"] >= I_DAG - pd.Timedelta(days=dager)] if not D.prognoser.empty else D.prognoser
        lt = ter.dropna(subset=["lt_fart_ms"]) if "lt_fart_ms" in ter else pd.DataFrame()
        stripe([
            ("VO2 maks løp", tall(P.siste(DAG["vo2max_lop"])[1] if D.har("vo2max_lop") else None, 0), "", "Garmin"),
            ("5 km-prognose", tempo(prog["tid_5k_s"].dropna().iloc[-1]) if "tid_5k_s" in prog and prog["tid_5k_s"].notna().any() else "–", "", "Garmin"),
            ("10 km-prognose", tempo(prog["tid_10k_s"].dropna().iloc[-1]) if "tid_10k_s" in prog and prog["tid_10k_s"].notna().any() else "–", "", "Garmin"),
            ("Terskelfart", f"{tempo(1000 / lt['lt_fart_ms'].iloc[-1])} <small>/km</small>" if not lt.empty else "–",
             f"Terskelpuls {lt['lt_puls'].dropna().iloc[-1]:.0f}" if not lt.empty and "lt_puls" in lt and lt["lt_puls"].notna().any() else "", "Garmin"),
            ("Løpsvolum", f"{tall(lop['km'].sum(), 0)} <small>km</small>" if not lop.empty else "–", f"{len(lop)} økter", "Garmin"),
        ])
        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown("### VO2 maks og prognoser")
            if not D.har("vo2max_lop") and prog.empty:
                utilgjengelig("VO2 maks og prognoser for løp er ikke tilgjengelig ennå.")
            else:
                fig = make_subplots(specs=[[{"secondary_y": True}]])
                if "tid_5k_s" in prog and prog["tid_5k_s"].notna().any():
                    linje(fig, prog["dato"], prog["tid_5k_s"] / 60, "5 km (min)", FARGE["Løping"], punkter=False, hover="%{y:.1f} min")
                if "tid_10k_s" in prog and prog["tid_10k_s"].notna().any():
                    linje(fig, prog["dato"], prog["tid_10k_s"] / 60, "10 km (min)", "#B0688C", punkter=False, hover="%{y:.1f} min")
                if D.har("vo2max_lop"):
                    linje(fig, p.index, p["vo2max_lop"], "VO2 maks", FARGE["tekst"], punkter=False, secondary_y=True)
                fig.update_yaxes(autorange="reversed", secondary_y=False)
                fig.update_yaxes(showgrid=False, secondary_y=True)
                vis(fig, 280)
                st.caption("Prognosetidene er invertert, slik at kortere tid vises høyere.")
        with c2:
            st.markdown("### Fart og puls per økt")
            e = lop[(lop["minutter"] >= 20) & (lop["km"] > 0)] if not lop.empty else lop
            if e.empty:
                utilgjengelig("Ingen løpeøkter over 20 minutter i perioden.")
            else:
                sek_km = e["minutter"] * 60 / e["km"]
                fig = go.Figure()
                fig.add_scatter(x=e["start"], y=sek_km / 60, mode="markers", name="Tempo",
                                marker=dict(size=8, color=e["snittpuls"] if "snittpuls" in e else FARGE["Løping"],
                                            colorscale=[[0, "#5C7A99"], [1, FARGE["Løping"]]], showscale=True,
                                            colorbar=dict(title="puls", thickness=8, len=0.7)),
                                customdata=np.stack([sek_km.map(tempo), e["snittpuls"].fillna(0)], axis=1) if "snittpuls" in e else None,
                                hovertemplate="%{customdata[0]} /km · %{customdata[1]:.0f} bpm<extra></extra>")
                fig.update_yaxes(autorange="reversed", title="min/km")
                fig.update_layout(hovermode="closest")
                vis(fig, 280, legende=False)
        e = lop[(lop["minutter"] >= 30) & (lop["km"] > 0)] if not lop.empty else lop
        if not e.empty and "snittpuls" in e and e["snittpuls"].notna().sum() >= 5:
            st.markdown(f"### Meter per hjerteslag {kilde('Beregnet')}", unsafe_allow_html=True)
            mps = (e["km"] * 1000) / (e["minutter"] * e["snittpuls"])
            fig = go.Figure()
            fig.add_scatter(x=e["start"], y=mps, mode="markers", name="Økt", marker=dict(color=FARGE["dempet"], size=6),
                            hovertemplate="%{y:.2f} m/slag")
            fig.add_scatter(x=e["start"], y=mps.rolling(5, min_periods=3).mean(), name="Glidende snitt (5 økter)",
                            line=dict(color=FARGE["Løping"], width=2))
            vis(fig, 240)
            st.caption("Aerob effektivitet for løpeturer over 30 min: distanse delt på antall hjerteslag. Påvirkes av terreng, vær og øktens innhold.")
        oko = [k for k in ["kadens_lop", "bakkekontakt_ms", "vertikal_osc"] if k in lop and lop[k].notna().any()]
        if oko:
            st.markdown(f"### Løpsøkonomi {kilde('Garmin')}", unsafe_allow_html=True)
            fig = make_subplots(rows=1, cols=len(oko), subplot_titles=[
                {"kadens_lop": "Kadens (spm)", "bakkekontakt_ms": "Bakkekontakt (ms)", "vertikal_osc": "Vertikal oscillasjon (cm)"}[k] for k in oko])
            for i, k in enumerate(oko, 1):
                fig.add_scatter(x=lop["start"], y=lop[k], mode="markers", marker=dict(color=FARGE["Løping"], size=5),
                                showlegend=False, row=1, col=i, hovertemplate="%{y:.1f}")
            fig.update_annotations(font_size=12)
            vis(fig, 220, legende=False)

    # ---------------- Svømming
    with t3:
        sv = o[(o["sport"] == "Svømming") & (o["km"] > 0)] if not o.empty else o
        if sv.empty:
            utilgjengelig("Ingen svømmeøkter i perioden.")
        else:
            varighet = (sv["bevegelse_s"].fillna(sv["minutter"] * 60) if "bevegelse_s" in sv else sv["minutter"] * 60)
            per100 = varighet / (sv["km"] * 10)
            stripe([
                ("Svømmedistanse", f"{tall(sv['km'].sum() * 1000, 0)} <small>m</small>", f"{len(sv)} økter", "Garmin"),
                ("Snittfart", f"{tempo(per100.median())} <small>/100 m</small>", "Median for perioden", "Beregnet"),
                ("Snittpuls", tall(sv["snittpuls"].mean()) if "snittpuls" in sv else "–", "", "Garmin"),
                ("SWOLF", tall(sv["swolf"].mean()) if "swolf" in sv and sv["swolf"].notna().any() else "–", "Lavere er bedre", "Garmin"),
            ])
            c1, c2 = st.columns(2, gap="large")
            with c1:
                st.markdown("### Fart per 100 m")
                fig = go.Figure()
                fig.add_scatter(x=sv["start"], y=per100, mode="markers", name="Økt", marker=dict(color=FARGE["dempet"], size=7),
                                customdata=per100.map(tempo), hovertemplate="%{customdata} /100 m<extra></extra>")
                fig.add_scatter(x=sv["start"], y=per100.rolling(5, min_periods=3).median(), name="Glidende median",
                                line=dict(color=FARGE["Svømming"], width=2), hoverinfo="skip")
                fig.update_yaxes(autorange="reversed", title="sek/100 m")
                vis(fig, 280)
            with c2:
                st.markdown("### Ukentlig svømmevolum")
                w = sv.assign(uke=P.uke(sv)).groupby("uke")["km"].sum() * 1000
                fig = go.Figure(go.Bar(x=w.index, y=w, marker_color=FARGE["Svømming"], hovertemplate="%{y:.0f} m<extra></extra>"))
                vis(fig, 280, legende=False)


# ================================================================== BELASTNING

def belastning():
    st.title("Belastning og restitusjon")
    hint_ekstra()
    dager = st.segmented_control("Periode", [42, 90, 180, 365], default=90, required=True, format_func=lambda x: f"{x} d",
                                 label_visibility="collapsed", key="bl_per")
    p = periode(DAG, dager)
    siste28 = periode(DAG, 28)
    acwr = P.siste(DAG["acwr"])[1] if D.har("acwr") else None
    stripe([
        ("Akutt belastning", tall(P.siste(DAG["belastning_akutt"])[1] if D.har("belastning_akutt") else None), "7 dager", D.last_kilde),
        ("Kronisk belastning", tall(P.siste(DAG["belastning_kronisk"])[1] if D.har("belastning_kronisk") else None), "28 dager", D.last_kilde),
        ("Akutt/kronisk", tall(acwr, 2), "Vanlig område 0,8–1,3", D.last_kilde),
        ("Hviledager", str(int((siste28["okter"] == 0).sum())), "Siste 28 dager", None),
        ("Dobbeltøktdager", str(int((siste28["okter"] >= 2).sum())), "Siste 28 dager", None),
        ("Treningsdager på rad", str(P.treningsdager_rad(D)), "", None),
    ])

    st.markdown(f"### Akutt og kronisk belastning {kilde(D.last_kilde)}", unsafe_allow_html=True)
    if not D.har("belastning_akutt"):
        utilgjengelig("Belastningsdata er ikke tilgjengelig ennå. Det krever minst fire ukers økter.")
    else:
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        if "okt_belastning" in p:
            fig.add_bar(x=p.index, y=p["okt_belastning"], name="Daglig belastning", marker_color="#2E3A4D",
                        hovertemplate="%{y:.0f}", secondary_y=False)
        linje(fig, p.index, p["belastning_akutt"], "Akutt", FARGE["Løping"], punkter=False, hover="%{y:.0f}")
        linje(fig, p.index, p["belastning_kronisk"], "Kronisk", FARGE["Svømming"], punkter=False, hover="%{y:.0f}")
        if D.har("acwr"):
            fig.add_scatter(x=p.index, y=p["acwr"], name="Akutt/kronisk", line=dict(color=FARGE["tekst"], width=1, dash="dot"),
                            hovertemplate="%{y:.2f}", secondary_y=True)
            fig.add_hrect(y0=0.8, y1=1.3, fillcolor="rgba(76,183,130,0.07)", line_width=0, secondary_y=True)
        fig.update_yaxes(showgrid=False, range=[0, 2.2], secondary_y=True)
        vis(fig, 330)
        if D.last_kilde == "Beregnet":
            st.caption("Beregnet: akutt = sum siste 7 dager, kronisk = snitt per uke siste 28 dager, fra øktbelastningen.")
        else:
            st.caption("Garmins akutte og kroniske belastning. Feltet 0,8–1,3 er det vanlig anbefalte forholdet; over 1,5 er en rask økning.")

    if D.har("last_aerob_lav"):
        st.markdown(f"### Belastningsfordeling siste 4 uker {kilde('Garmin')}", unsafe_allow_html=True)
        r = DAG[["last_aerob_lav", "last_aerob_hoy", "last_anaerob"]].dropna().iloc[-1]
        fig = go.Figure()
        for k, n, c in [("last_aerob_lav", "Lav aerob", "#5C7A99"), ("last_aerob_hoy", "Høy aerob", "#9FB4D9"),
                        ("last_anaerob", "Anaerob", "#E6EDF7")]:
            fig.add_bar(y=[""], x=[r[k]], name=n, orientation="h", marker_color=c, hovertemplate=f"{n}: %{{x:.0f}}<extra></extra>")
        fig.update_layout(barmode="stack", hovermode="closest")
        vis(fig, 120)
        tekst = DAG["lastbalanse"].dropna().iloc[-1] if D.har("lastbalanse") else None
        if tekst:
            st.caption(f"Garmins vurdering: {str(tekst).replace('_', ' ').lower()}")

    st.markdown("### Hvordan kroppen responderer")
    st.caption("Grafene viser samvariasjon over tid. De beviser ikke årsakssammenhenger.")
    c1, c2 = st.columns(2, gap="large")

    def mot(kol, navn, enhet, farge):
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        if "okt_belastning" in p and p["okt_belastning"].notna().any():
            fig.add_bar(x=p.index, y=p["okt_belastning"], name="Belastning", marker_color="#2E3A4D", hovertemplate="%{y:.0f}")
        else:
            fig.add_bar(x=p.index, y=p["trening_min"], name="Treningstid (min)", marker_color="#2E3A4D", hovertemplate="%{y:.0f}")
        fig.add_scatter(x=p.index, y=p[kol], mode="markers", name=navn, marker=dict(color=farge, size=4, opacity=0.6),
                        secondary_y=True, hovertemplate=f"%{{y:.0f}} {enhet}")
        fig.add_scatter(x=p.index, y=p[kol].rolling(7, min_periods=3).mean(), name=f"{navn} 7 d", line=dict(color=farge, width=2),
                        secondary_y=True, hovertemplate=f"%{{y:.0f}} {enhet}")
        fig.update_yaxes(showgrid=False, secondary_y=True)
        return fig

    with c1:
        st.markdown("**Belastning og HRV**")
        if D.har("hrv_natt"):
            vis(mot("hrv_natt", "HRV", "ms", FARGE["aksent"]), 260)
        else:
            utilgjengelig("HRV er ikke tilgjengelig.")
    with c2:
        st.markdown("**Belastning og hvilepuls**")
        if D.har("hvilepuls"):
            vis(mot("hvilepuls", "Hvilepuls", "bpm", FARGE["Løping"]), 260)
        else:
            utilgjengelig("Hvilepuls er ikke tilgjengelig.")

    c3, c4 = st.columns(2, gap="large")
    with c3:
        y_kol = "beredskap_score" if D.har("beredskap_score") else "hrv_natt" if D.har("hrv_natt") else None
        st.markdown(f"**Søvn og {'treningsberedskap' if y_kol == 'beredskap_score' else 'HRV'} morgenen etter**")
        if y_kol and D.har("sovn_timer"):
            x = p[["sovn_timer", y_kol]].replace({"sovn_timer": {0: np.nan}}).dropna()
            if len(x) >= 10:
                fig = go.Figure(go.Scatter(x=x["sovn_timer"], y=x[y_kol], mode="markers",
                                           marker=dict(color=FARGE["aksent"], size=7, opacity=0.75),
                                           hovertemplate="%{x:.1f} t søvn → %{y:.0f}<extra></extra>"))
                fig.update_xaxes(title="Søvn (timer)")
                fig.update_layout(hovermode="closest")
                vis(fig, 260, legende=False)
                r = np.corrcoef(x["sovn_timer"], x[y_kol])[0, 1]
                st.caption(f"Korrelasjon r = {P._k(r, '.2f')} over {len(x)} netter "
                           f"({'svak' if abs(r) < 0.3 else 'moderat' if abs(r) < 0.5 else 'tydelig'} samvariasjon).")
            else:
                utilgjengelig("For få netter i perioden.")
        else:
            utilgjengelig("Krever søvndata og HRV eller treningsberedskap.")
    with c4:
        st.markdown("**Ukentlig volum og VO2 maks**")
        vo = "vo2max_sykkel" if D.har("vo2max_sykkel") and not D.har("vo2max_lop") else "vo2max_lop"
        if D.har(vo):
            w = p.resample("W-SUN").agg({"trening_min": "sum", "vo2max_lop": "last", "vo2max_sykkel": "last"}
                                        if D.har("vo2max_sykkel") and D.har("vo2max_lop") else {"trening_min": "sum", vo: "last"})
            fig = make_subplots(specs=[[{"secondary_y": True}]])
            fig.add_bar(x=w.index, y=w["trening_min"] / 60, name="Timer per uke", marker_color="#2E3A4D", hovertemplate="%{y:.1f} t")
            for k, n, c in [("vo2max_lop", "VO2 maks løp", FARGE["Løping"]), ("vo2max_sykkel", "VO2 maks sykkel", FARGE["Sykling"])]:
                if k in w and w[k].notna().any():
                    fig.add_scatter(x=w.index, y=w[k], name=n, line=dict(color=c, width=2), secondary_y=True, hovertemplate="%{y:.0f}")
            fig.update_yaxes(showgrid=False, secondary_y=True)
            vis(fig, 260)
        else:
            utilgjengelig("VO2 maks er ikke tilgjengelig.")


# ================================================================== ANALYSE

def analyse():
    st.title("Historisk analyse")
    st.markdown('<p class="dempet" style="max-width:75ch">Innsiktene under regnes ut automatisk fra dine historiske data. '
                'En innsikt vises bare når datagrunnlaget er stort nok, og den beskriver hva som har skjedd samtidig, '
                'ikke hva som er årsak.</p>', unsafe_allow_html=True)
    hint_ekstra()
    liste = P.innsikter(D)
    if not liste:
        utilgjengelig("For lite historikk til automatiske innsikter ennå. De fleste analysene krever 8–16 uker med data. "
                      "Hent mer historikk med `python hent_data.py --dager 365` og `python hent_ekstra.py --dager 365`.")
        return
    for x in liste:
        st.markdown(f'<div class="innsikt"><h4>{x["tittel"]}</h4><p>{x["tekst"]}</p>'
                    f'<div class="g">Grunnlag: {x["grunnlag"]} {kilde("Beregnet")}</div></div>', unsafe_allow_html=True)

    st.markdown("### Spørsmål som venter på mer data")
    besvart = {x["tittel"] for x in liste}
    venter = [
        ("Treningsvolum og respons", "Hvordan reagerer HRV og hvilepuls når volumet øker?", "8 uker med økter"),
        ("HRV etter tunge uker", "Hvordan responderer HRV etter uker med høy treningsmengde?", "8 uker med HRV"),
        ("Hvilepuls etter harde økter", "Øker hvilepulsen etter harde terskeløkter?", "5 harde og 5 rolige dager med treningseffekt-data"),
        ("Søvnlengde og morgenen etter", "Er formen bedre etter netter med over 8 timers søvn?", "5 netter over 8 t og 5 under 7 t"),
        ("Dobbeltøkter på rad", "Hvordan påvirkes restitusjonen av dobbeltøkter flere dager på rad?", "3 perioder"),
    ]
    rest = [v for v in venter if v[0] not in besvart]
    if rest:
        st.markdown("".join(f'<p class="dempet">{q} <span style="opacity:.7">(krever {k})</span></p>' for _, q, k in rest),
                    unsafe_allow_html=True)
    else:
        st.caption("Alle standardspørsmålene har nok data.")


# ================================================================== KALENDER

IKON = {"Svømming": "🏊", "Sykling": "🚴", "Løping": "🏃", "Styrke": "🏋️", "Annet": "•"}
def kalender():
    st.title("Treningskalender")
    if OK.empty:
        utilgjengelig("Ingen økter registrert.")
        return
    mnd_liste = pd.period_range(OK["dato"].min(), I_DAG, freq="M")[::-1]
    valgt = st.selectbox("Måned", mnd_liste, format_func=lambda m: f"{MND[m.month - 1]} {m.year}".capitalize(),
                         label_visibility="collapsed")
    start = valgt.start_time
    slutt = valgt.end_time.normalize()
    o = OK[(OK["dato"] >= start) & (OK["dato"] <= slutt)]
    st.caption(f"{len(o)} økter · {t_min(o['minutter'].sum())} · {o['dato'].nunique()} treningsdager")

    hoder = st.columns(7)
    for i, n in enumerate(["Man", "Tir", "Ons", "Tor", "Fre", "Lør", "Søn"]):
        hoder[i].markdown(f'<div class="dag">{n}</div>', unsafe_allow_html=True)

    dag = start - pd.Timedelta(days=start.weekday())
    while dag <= slutt:
        kol = st.columns(7)
        for i in range(7):
            d = dag + pd.Timedelta(days=i)
            with kol[i]:
                if d.month != valgt.month:
                    continue
                dag_okt = o[o["dato"] == d]
                bel = dag_okt["belastning"].sum() if "belastning" in dag_okt and dag_okt["belastning"].notna().any() else None
                st.markdown(f'<div class="dag{" idag" if d == I_DAG else ""}">{d.day}'
                            f'{f" · belastning {bel:.0f}" if bel else ""}</div>', unsafe_allow_html=True)
                for r in dag_okt.itertuples():
                    tekst = f"{IKON[r.sport]} {t_min(r.minutter)}"
                    if r.km and r.km > 0:
                        tekst += f" · {r.km * 1000:.0f} m" if r.sport == "Svømming" else f" · {P._k(r.km, '.1f')} km"
                    if getattr(r, "snittpuls", None) and pd.notna(r.snittpuls):
                        tekst += f" · {r.snittpuls:.0f} bpm"
                    if st.button(tekst, key=f"okt_{r.id}", width="stretch"):
                        st.session_state["valgt_okt"] = r.id
        dag += pd.Timedelta(days=7)

    vid = st.session_state.get("valgt_okt")
    if vid is not None and (OK["id"] == vid).any():
        r = OK[OK["id"] == vid].iloc[0]
        st.markdown(f"### {IKON[r['sport']]} {r.get('navn') or r['sport']}")
        st.caption(f"{dato_norsk(r['start'], klokke=True)} · {r['sport']}")
        felt = [("Varighet", t_min(r["minutter"]), "", "Garmin")]
        if r.get("km"):
            if r["sport"] == "Svømming":
                felt.append(("Distanse", f"{r['km'] * 1000:.0f} <small>m</small>", f"{tempo(r['minutter'] * 60 / (r['km'] * 10))} /100 m", "Garmin"))
            elif r["sport"] == "Løping":
                felt.append(("Distanse", f"{P._k(r['km'], '.2f')} <small>km</small>", f"{tempo(r['minutter'] * 60 / r['km'])} /km", "Garmin"))
            else:
                felt.append(("Distanse", f"{P._k(r['km'], '.1f')} <small>km</small>", f"{P._k(r['km'] / (r['minutter'] / 60), '.1f')} km/t", "Garmin"))
        felt.append(("Puls", tall(r.get("snittpuls"), 0, "bpm"), f"Maks {r['makspuls']:.0f}" if pd.notna(r.get("makspuls")) else "", "Garmin"))
        if pd.notna(r.get("snitteffekt")):
            felt.append(("Effekt", tall(r["snitteffekt"], 0, "W"), f"NP {r['np']:.0f} W" if pd.notna(r.get("np")) else "", "Garmin"))
        felt.append(("Belastning", tall(r.get("belastning")), "TRIMP" if r.get("belastning_beregnet") else "",
                     "Beregnet" if r.get("belastning_beregnet") else "Garmin"))
        if pd.notna(r.get("te_aerob")):
            felt.append(("Treningseffekt", f"{P._k(r['te_aerob'], '.1f')} <small>/ {P._k(r.get('te_anaerob', 0), '.1f')}</small>", "Aerob / anaerob", "Garmin"))
        felt.append(("Kalorier", tall(r.get("kalorier"), 0, "kcal"), "", "Garmin"))
        stripe(felt)
        soner = [f"puls_sone{i}_s" for i in range(1, 6)]
        if all(s in r.index for s in soner) and pd.notna(r[soner]).any():
            v = r[soner].fillna(0).astype(float) / 60
            fig = go.Figure(go.Bar(x=[f"Sone {i}" for i in range(1, 6)], y=v,
                                   marker_color=["#3A4A60", "#5C7A99", "#9FB4D9", "#E3B341", "#E5534B"],
                                   hovertemplate="%{y:.0f} min<extra></extra>"))
            fig.update_yaxes(ticksuffix=" min")
            st.markdown("**Tid i pulssoner**")
            vis(fig, 220, legende=False)


# ================================================================== NAVIGASJON

sider = st.navigation([
    st.Page(oversikt, title="Oversikt", url_path="oversikt", default=True),
    st.Page(helse, title="Helse og restitusjon", url_path="helse"),
    st.Page(trening, title="Trening", url_path="trening"),
    st.Page(prestasjon, title="Prestasjonsutvikling", url_path="prestasjon"),
    st.Page(belastning, title="Belastning", url_path="belastning"),
    st.Page(analyse, title="Historisk analyse", url_path="analyse"),
    st.Page(kalender, title="Treningskalender", url_path="kalender"),
], position="top")
sider.run()
