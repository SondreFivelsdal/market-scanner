"""
Tilleggsscript for prestasjonssenteret.

Henter målingene som hent_data.py ikke henter: HRV, treningsberedskap,
treningsstatus og -belastning, VO2 maks (løp og sykkel hver for seg),
respirasjon, SpO2, vekt, FTP, laktatterskel, løpsprognoser og detaljerte
øktdata (effekt, NP, soner, treningseffekt, belastning).

hent_data.py blir ikke endret. Dette scriptet bruker den samme lagrede
innloggingen (.garmin_tokens), og lagrer i egne filer i data/:

    ekstra_daglig.csv         én rad per dag
    aktiviteter_detaljer.csv  én rad per økt
    terskler.csv              FTP og laktatterskel over tid
    prognoser.csv             Garmins løpsprognoser over tid
    vekt.csv                  veiinger

Bruk:
    python hent_ekstra.py               # siste 30 dager (henter bare dager som mangler)
    python hent_ekstra.py --dager 365   # første gang: ett års historikk
    python hent_ekstra.py --diagnose    # viser strukturen i Garmin-svarene (uten verdier)
"""
import argparse
import json
import os
import sys
import time
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from garminconnect import Garmin

try:
    from garminconnect import GarminConnectTooManyRequestsError
except ImportError:  # eldre versjoner
    class GarminConnectTooManyRequestsError(Exception):
        pass

MAPPE = Path(__file__).parent
DATA = MAPPE / "data"
RAA = DATA / "raa"
TOKENS = MAPPE / ".garmin_tokens"


class Stopp(Exception):
    """Garmin begrenser antall forespørsler. Lagrer og avslutter."""


# ---------------------------------------------------------------- hjelpere

def logg_inn() -> Garmin:
    load_dotenv(MAPPE / ".env")
    epost, passord = os.getenv("GARMIN_EMAIL"), os.getenv("GARMIN_PASSWORD")
    TOKENS.mkdir(exist_ok=True)
    api = Garmin(epost, passord, prompt_mfa=lambda: input("Skriv inn MFA-koden fra Garmin: "))
    api.login(str(TOKENS))
    return api


_lagret_eksempel = set()


def kall(navn, fn, *args, **kwargs):
    """Kaller Garmin trygt. Lagrer første svar per endepunkt i data/raa/ for feilsøking."""
    try:
        svar = fn(*args, **kwargs)
    except GarminConnectTooManyRequestsError as e:
        raise Stopp(str(e))
    except Exception as e:
        tekst = str(e)
        if "429" in tekst or "Too Many" in tekst:
            raise Stopp(tekst)
        return None
    if svar and navn not in _lagret_eksempel:
        RAA.mkdir(parents=True, exist_ok=True)
        try:
            (RAA / f"{navn}.json").write_text(json.dumps(svar, indent=1, default=str), encoding="utf-8")
            _lagret_eksempel.add(navn)
        except Exception:
            pass
    return svar


def finn(obj, *sti):
    for nokkel in sti:
        if not isinstance(obj, dict):
            return None
        obj = obj.get(nokkel)
    return obj


def primaer(kart):
    """Garmin grupperer noen målinger per klokke. Velg primær treningsenhet."""
    if not isinstance(kart, dict) or not kart:
        return {}
    verdier = [v for v in kart.values() if isinstance(v, dict)]
    for v in verdier:
        if v.get("primaryTrainingDevice"):
            return v
    return verdier[0] if verdier else {}


def tall(x):
    return x if isinstance(x, (int, float)) and not isinstance(x, bool) else None


def dato_verdier(obj):
    """Finner (dato, verdi)-par i Garmins biometriske tidsserier, uansett nøsting."""
    ut = []

    def gaa(x):
        if isinstance(x, dict):
            d = x.get("calendarDate") or x.get("from") or x.get("date") or x.get("summaryDate")
            v = tall(x.get("value"))
            if d and v is not None:
                ut.append((str(d)[:10], v))
            for y in x.values():
                gaa(y)
        elif isinstance(x, list):
            for y in x:
                gaa(y)

    gaa(obj)
    return ut


def biter(start: date, slutt: date, dager: int):
    a = start
    while a <= slutt:
        b = min(a + timedelta(days=dager - 1), slutt)
        yield a, b
        a = b + timedelta(days=1)


# ---------------------------------------------------------------- per dag

def hent_dag(api, d: str) -> dict:
    rad = {"dato": d}

    # HRV
    s = finn(kall("hrv", api.get_hrv_data, d), "hrvSummary") or {}
    rad.update(
        hrv_natt=tall(s.get("lastNightAvg")),
        hrv_7d=tall(s.get("weeklyAvg")),
        hrv_status=s.get("status"),
        hrv_normal_lav=tall(finn(s, "baseline", "balancedLow")),
        hrv_normal_hoy=tall(finn(s, "baseline", "balancedUpper")),
    )

    # Treningsberedskap (morgenverdien, ellers første registrering den dagen)
    tr = None
    if hasattr(api, "get_morning_training_readiness"):
        tr = kall("beredskap_morgen", api.get_morning_training_readiness, d)
    if not tr:
        tr = kall("beredskap", api.get_training_readiness, d)
    if isinstance(tr, list):
        tr = sorted(tr, key=lambda x: str(x.get("timestamp") or ""))[0] if tr else None
    tr = tr or {}
    rad.update(
        beredskap_score=tall(tr.get("score")),
        beredskap_niva=tr.get("level"),
        beredskap_tekst=tr.get("feedbackShort"),
        restitusjonstid_min=tall(tr.get("recoveryTime")),
    )

    # Treningsstatus, belastning og VO2 maks
    ts = kall("treningsstatus", api.get_training_status, d) or {}
    lop = finn(ts, "mostRecentVO2Max", "generic") or {}
    syk = finn(ts, "mostRecentVO2Max", "cycling") or {}
    p = primaer(finn(ts, "mostRecentTrainingStatus", "latestTrainingStatusData"))
    akutt = p.get("acuteTrainingLoadDTO") or {}
    lb = primaer(finn(ts, "mostRecentTrainingLoadBalance", "metricsTrainingLoadBalanceDTOMap"))
    rad.update(
        vo2max_lop=tall(lop.get("vo2MaxPreciseValue")) or tall(lop.get("vo2MaxValue")),
        vo2max_lop_dato=lop.get("calendarDate"),
        vo2max_sykkel=tall(syk.get("vo2MaxPreciseValue")) or tall(syk.get("vo2MaxValue")),
        vo2max_sykkel_dato=syk.get("calendarDate"),
        treningsstatus=p.get("trainingStatusFeedbackPhrase"),
        belastning_akutt=tall(akutt.get("dailyTrainingLoadAcute")),
        belastning_kronisk=tall(akutt.get("dailyTrainingLoadChronic")),
        acwr=tall(akutt.get("dailyAcuteChronicWorkloadRatio")),
        acwr_status=akutt.get("acwrStatus"),
        last_aerob_lav=tall(lb.get("monthlyLoadAerobicLow")),
        last_aerob_hoy=tall(lb.get("monthlyLoadAerobicHigh")),
        last_anaerob=tall(lb.get("monthlyLoadAnaerobic")),
        lastbalanse=lb.get("trainingBalanceFeedbackPhrase"),
    )

    # Respirasjon og SpO2
    r = kall("respirasjon", api.get_respiration_data, d) or {}
    rad.update(
        resp_sovn=tall(r.get("avgSleepRespirationValue")),
        resp_vaaken=tall(r.get("avgWakingRespirationValue")),
    )
    o = kall("spo2", api.get_spo2_data, d) or {}
    rad.update(
        spo2_snitt=tall(o.get("averageSpO2")),
        spo2_sovn=tall(o.get("avgSleepSpO2")),
        spo2_lavest=tall(o.get("lowestSpO2")),
    )
    return rad


# ---------------------------------------------------------------- økter

AKTIVITETSFELT = {
    "activityId": "id", "startTimeLocal": "start", "activityName": "navn",
    "duration": "varighet_s", "movingDuration": "bevegelse_s", "distance": "distanse_m",
    "calories": "kalorier", "averageHR": "snittpuls", "maxHR": "makspuls",
    "averageSpeed": "snittfart_ms", "elevationGain": "hoydemeter",
    "avgPower": "snitteffekt", "maxPower": "makseffekt", "normPower": "np",
    "trainingStressScore": "tss", "intensityFactor": "if_",
    "aerobicTrainingEffect": "te_aerob", "anaerobicTrainingEffect": "te_anaerob",
    "trainingEffectLabel": "te_type", "activityTrainingLoad": "treningslast",
    "vO2MaxValue": "vo2max_okt",
    "averageRunningCadenceInStepsPerMinute": "kadens_lop",
    "averageBikingCadenceInRevPerMinute": "kadens_sykkel",
    "avgGroundContactTime": "bakkekontakt_ms", "avgVerticalOscillation": "vertikal_osc",
    "avgStrideLength": "steglengde",
    "averageSwimCadenceInStrokesPerMinute": "tak_min", "averageSwolf": "swolf",
    "poolLength": "bassenglengde", "activeLengths": "lengder",
}


def hent_okter(api, start: date, slutt: date) -> pd.DataFrame:
    liste = kall("aktiviteter", api.get_activities_by_date, start.isoformat(), slutt.isoformat()) or []
    rader = []
    for a in liste:
        rad = {ny: a.get(gml) for gml, ny in AKTIVITETSFELT.items()}
        rad["type"] = finn(a, "activityType", "typeKey") or "annet"
        for i in range(1, 6):
            rad[f"puls_sone{i}_s"] = a.get(f"hrTimeInZone_{i}")
            rad[f"effekt_sone{i}_s"] = a.get(f"powerTimeInZone_{i}")
        rader.append(rad)
    return pd.DataFrame(rader)


# ---------------------------------------------------------------- tidsserier

def hent_terskler(api, start: date, slutt: date) -> pd.DataFrame:
    rader = {}

    def legg(d, kol, v):
        rader.setdefault(d, {"dato": d})[kol] = v

    for a, b in biter(start, slutt, 360):
        if hasattr(api, "get_functional_threshold_power_range"):
            ftp = kall("ftp", api.get_functional_threshold_power_range,
                       a.isoformat(), b.isoformat(), sport="CYCLING", aggregation="daily")
            for d, v in dato_verdier(ftp):
                legg(d, "ftp", v)
        lt = kall("laktat", api.get_lactate_threshold, latest=False,
                  start_date=a.isoformat(), end_date=b.isoformat(), aggregation="daily") or {}
        for d, v in dato_verdier(lt.get("speed")):
            # Garmin lagrer laktatterskelfart i enheten 10 m/s
            legg(d, "lt_fart_ms", v * 10 if v < 1.5 else v)
        for d, v in dato_verdier(lt.get("heart_rate")):
            legg(d, "lt_puls", v)
        for d, v in dato_verdier(lt.get("power")):
            legg(d, "lt_effekt_lop", v)
    return pd.DataFrame(list(rader.values()))


def hent_prognoser(api, start: date, slutt: date) -> pd.DataFrame:
    rader = []
    for a, b in biter(start, slutt, 360):
        svar = kall("prognoser", api.get_race_predictions, a.isoformat(), b.isoformat(), "daily") or []
        if isinstance(svar, dict):
            svar = [svar]
        for p in svar:
            if not isinstance(p, dict) or not p.get("calendarDate"):
                continue
            rader.append({
                "dato": str(p["calendarDate"])[:10],
                "tid_5k_s": tall(p.get("time5K")), "tid_10k_s": tall(p.get("time10K")),
                "tid_halv_s": tall(p.get("timeHalfMarathon")), "tid_maraton_s": tall(p.get("timeMarathon")),
            })
    return pd.DataFrame(rader)


def hent_vekt(api, start: date, slutt: date) -> pd.DataFrame:
    rader = []
    for a, b in biter(start, slutt, 360):
        svar = kall("vekt", api.get_weigh_ins, a.isoformat(), b.isoformat()) or {}
        for s in svar.get("dailySummaries") or []:
            w = tall(finn(s, "latestWeight", "weight"))
            if w:
                rader.append({
                    "dato": str(s.get("summaryDate"))[:10],
                    "vekt_kg": round(w / 1000 if w > 1000 else w, 1),
                    "fettprosent": tall(finn(s, "latestWeight", "bodyFat")),
                })
    return pd.DataFrame(rader)


# ---------------------------------------------------------------- lagring

def lagre(ny: pd.DataFrame, navn: str, nokkel: str):
    fil = DATA / navn
    if fil.exists():
        gammel = pd.read_csv(fil)
        ny = pd.concat([gammel, ny]) if not ny.empty else gammel
    if ny.empty:
        return 0
    ny[nokkel] = ny[nokkel].astype(str)
    ny = ny.drop_duplicates(subset=nokkel, keep="last").sort_values(nokkel)
    ny.to_csv(fil, index=False)
    return len(ny)


def diagnose():
    """Skriver ut nøklene i lagrede Garmin-svar, uten selve verdiene."""
    if not RAA.exists():
        sys.exit("Ingen lagrede svar ennå. Kjør python hent_ekstra.py først.")

    def struktur(x, inn=0, maks=4):
        pre = "  " * inn
        if inn > maks:
            return
        if isinstance(x, dict):
            for k, v in list(x.items())[:40]:
                print(f"{pre}{k}: {type(v).__name__}")
                if isinstance(v, (dict, list)):
                    struktur(v, inn + 1, maks)
        elif isinstance(x, list) and x:
            print(f"{pre}[liste med {len(x)} elementer, første:]")
            struktur(x[0], inn + 1, maks)

    for f in sorted(RAA.glob("*.json")):
        print(f"\n=== {f.stem} ===")
        struktur(json.loads(f.read_text(encoding="utf-8")))


# ---------------------------------------------------------------- hovedløp

def main():
    p = argparse.ArgumentParser(description="Hent tilleggsdata til prestasjonssenteret")
    p.add_argument("--dager", type=int, default=30)
    p.add_argument("--alt", action="store_true", help="Hent alle dager på nytt, også de som finnes")
    p.add_argument("--diagnose", action="store_true")
    args = p.parse_args()
    if args.diagnose:
        return diagnose()

    DATA.mkdir(exist_ok=True)
    api = logg_inn()
    slutt = date.today()
    start = slutt - timedelta(days=args.dager - 1)

    fil = DATA / "ekstra_daglig.csv"
    finnes = set(pd.read_csv(fil)["dato"].astype(str)) if fil.exists() else set()
    nylig = {(slutt - timedelta(days=i)).isoformat() for i in range(3)}  # verdier kan oppdateres
    dager = [start + timedelta(days=i) for i in range(args.dager)]
    mangler = [d for d in dager if args.alt or d.isoformat() not in finnes or d.isoformat() in nylig]

    print(f"Henter dagsmålinger for {len(mangler)} dager (hopper over {len(dager) - len(mangler)} som finnes).")
    rader = []
    try:
        for i, d in enumerate(mangler, 1):
            print(f"  {d}  ({i}/{len(mangler)})", end="\r")
            rader.append(hent_dag(api, d.isoformat()))
            if i % 25 == 0:
                lagre(pd.DataFrame(rader), "ekstra_daglig.csv", "dato")
                rader = []
            time.sleep(0.3)
        print()
        lagre(pd.DataFrame(rader), "ekstra_daglig.csv", "dato")

        print("Henter økter med detaljer …")
        n_okt = lagre(hent_okter(api, start, slutt), "aktiviteter_detaljer.csv", "id")
        print("Henter FTP og laktatterskel …")
        lagre(hent_terskler(api, start, slutt), "terskler.csv", "dato")
        print("Henter løpsprognoser …")
        lagre(hent_prognoser(api, start, slutt), "prognoser.csv", "dato")
        print("Henter vekt …")
        lagre(hent_vekt(api, start, slutt), "vekt.csv", "dato")
    except Stopp:
        lagre(pd.DataFrame(rader), "ekstra_daglig.csv", "dato")
        print("\nGarmin ber oss vente litt (for mange forespørsler). Det som er hentet er lagret.")
        print("Vent 15–30 minutter og kjør samme kommando igjen; scriptet fortsetter der det slapp.")
        return

    df = pd.read_csv(fil)
    print(f"\nFerdig. {len(df)} dager og {n_okt} økter lagret.")
    print("Tilgjengelighet per måling (andel dager med verdi):")
    for kol in ["hrv_natt", "beredskap_score", "belastning_akutt", "vo2max_lop", "vo2max_sykkel",
                "resp_sovn", "spo2_snitt"]:
        if kol in df:
            print(f"  {kol:<18} {df[kol].notna().mean():>5.0%}")


if __name__ == "__main__":
    main()
